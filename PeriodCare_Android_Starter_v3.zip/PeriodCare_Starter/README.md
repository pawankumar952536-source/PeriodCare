# PeriodCare — Android starter (Version 3)

Bilingual Hindi + English menstrual-cycle tracking prototype built with Expo + React Native.

## Included
- Monthly calendar and period-day logging
- Symptom and mood tracking by date
- Adjustable cycle-length estimate (21–45 days)
- Optional local notification reminder, scheduled two days before the estimated next period at 9 AM
- JSON data export through the phone's native share menu
- Confirmed delete-all-data action
- Local storage only; no account, cloud sync, ads, or analytics included

## Run
1. Install Node.js on a computer.
2. Run `npm install`.
3. Run `npx expo start`.
4. Open with Expo Go or build a development/production Android app using EAS Build.

## Important limitations before any public release
This is a prototype, not a medically validated tracker. Its prediction uses a simple user-selected cycle length from the most recently marked period start. Real cycles can vary; never present the estimate as guaranteed, a diagnosis, contraception, or fertility advice.

The reminder is a local notification, not a server push notification. It is scheduled when the user enables it; if they change their cycle length or log a new period afterward, this prototype does not automatically reschedule the pending reminder. Review and improve that behavior before release.

Period data is sensitive. This version stores data locally using AsyncStorage, which is not encrypted secure storage. Do not release it for public use until storage protection, privacy disclosures, consent, age-appropriate design, accessibility, testing, data lifecycle controls, and Google Play policy/legal review are completed. Export uses the native share sheet; users choose where to send the JSON content.
