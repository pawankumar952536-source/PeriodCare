import React, { useEffect, useMemo, useState } from "react";
import {
  SafeAreaView, View, Text, StyleSheet, Pressable, ScrollView, Alert, Share, Platform
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Notifications from "expo-notifications";
import { StatusBar } from "expo-status-bar";

const STORAGE_KEY = "periodcare.data.v3";
const SETTINGS_KEY = "periodcare.settings.v1";
const SYMPTOMS = ["Cramps · ऐंठन", "Headache · सिरदर्द", "Bloating · पेट फूलना", "Tired · थकान", "Acne · मुहाँसे", "Tender breasts · स्तनों में दर्द"];
const MOODS = ["Okay · ठीक", "Happy · खुश", "Calm · शांत", "Sad · उदास", "Irritated · चिड़चिड़ापन", "Anxious · बेचैनी"];

type Entry = { date: string; period: boolean; symptoms: string[]; mood: string };
type Settings = { cycleLength: number; reminders: boolean };
const DEFAULT_SETTINGS: Settings = { cycleLength: 28, reminders: false };

function keyOf(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function dateFromKey(value: string) {
  const [y, m, d] = value.split("-").map(Number);
  return new Date(y, m - 1, d);
}
function pretty(value?: string) {
  return value ? dateFromKey(value).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" }) : "Not logged · दर्ज नहीं";
}
function shiftDate(date: Date, amount: number) {
  const copy = new Date(date);
  copy.setDate(copy.getDate() + amount);
  return copy;
}
function daysBetween(a: Date, b: Date) {
  return Math.round((new Date(a.getFullYear(), a.getMonth(), a.getDate()).getTime() -
    new Date(b.getFullYear(), b.getMonth(), b.getDate()).getTime()) / 86400000);
}

export default function App() {
  const today = new Date();
  const [entries, setEntries] = useState<Entry[]>([]);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [selectedDate, setSelectedDate] = useState(keyOf(today));
  const [month, setMonth] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [raw, rawSettings] = await Promise.all([
          AsyncStorage.getItem(STORAGE_KEY), AsyncStorage.getItem(SETTINGS_KEY)
        ]);
        if (raw) {
          const parsed = JSON.parse(raw);
          setEntries(Array.isArray(parsed.entries) ? parsed.entries : []);
        }
        if (rawSettings) setSettings({ ...DEFAULT_SETTINGS, ...JSON.parse(rawSettings) });
      } finally {
        setLoaded(true);
      }
    })();
  }, []);

  const selected = entries.find(e => e.date === selectedDate);
  const periodDates = entries.filter(e => e.period).map(e => e.date).sort();
  const lastPeriod = periodDates[periodDates.length - 1];
  const nextEstimate = lastPeriod ? keyOf(shiftDate(dateFromKey(lastPeriod), settings.cycleLength)) : undefined;
  const daysToNext = nextEstimate ? daysBetween(dateFromKey(nextEstimate), today) : undefined;

  async function persist(next: Entry[]) {
    setEntries(next);
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify({ entries: next }));
    } catch {
      Alert.alert("Could not save · सेव नहीं हुआ", "Please check your device storage.");
    }
  }

  async function saveSettings(next: Settings) {
    setSettings(next);
    await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(next));
  }

  async function updateSelected(change: Partial<Entry>) {
    const old = selected || { date: selectedDate, period: false, symptoms: [], mood: "" };
    const updated = { ...old, ...change };
    const next = [...entries.filter(e => e.date !== selectedDate), updated].sort((a, b) => a.date.localeCompare(b.date));
    await persist(next);
  }

  function toggleSymptom(symptom: string) {
    const current = selected?.symptoms || [];
    const next = current.includes(symptom) ? current.filter(s => s !== symptom) : [...current, symptom];
    updateSelected({ symptoms: next });
  }

  const calendarCells = useMemo(() => {
    const firstDay = new Date(month.getFullYear(), month.getMonth(), 1).getDay();
    const count = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
    return [...Array(firstDay).fill(null), ...Array.from({ length: count }, (_, i) => i + 1)];
  }, [month]);

  function changeMonth(delta: number) {
    setMonth(new Date(month.getFullYear(), month.getMonth() + delta, 1));
  }

  async function setReminder(enabled: boolean) {
    if (!enabled) {
      await Notifications.cancelAllScheduledNotificationsAsync();
      await saveSettings({ ...settings, reminders: false });
      Alert.alert("Reminders off · रिमाइंडर बंद", "PeriodCare reminders have been turned off.");
      return;
    }
    const permission = await Notifications.requestPermissionsAsync();
    if (!permission.granted) {
      Alert.alert("Permission needed · अनुमति ज़रूरी", "Allow notifications in your phone settings to enable reminders.");
      return;
    }
    await Notifications.cancelAllScheduledNotificationsAsync();
    if (nextEstimate) {
      const reminderDate = shiftDate(dateFromKey(nextEstimate), -2);
      reminderDate.setHours(9, 0, 0, 0);
      if (reminderDate.getTime() > Date.now()) {
        await Notifications.scheduleNotificationAsync({
          content: {
            title: "PeriodCare reminder 🌸",
            body: "Your next period may be approaching. This is only an estimate. · आपका अगला पीरियड करीब हो सकता है। यह सिर्फ अनुमान है।"
          },
          trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: reminderDate }
        });
      }
    }
    await saveSettings({ ...settings, reminders: true });
    Alert.alert("Reminder enabled · रिमाइंडर चालू", nextEstimate
      ? "A reminder is scheduled two days before your estimated date, if that date is still ahead."
      : "Reminder preference saved. Log a period start date to schedule the next estimate reminder.");
  }

  async function exportData() {
    const payload = {
      app: "PeriodCare",
      exportedAt: new Date().toISOString(),
      settings,
      entries
    };
    try {
      await Share.share({
        title: "PeriodCare data export",
        message: JSON.stringify(payload, null, 2)
      });
    } catch {
      Alert.alert("Export unavailable · एक्सपोर्ट नहीं हुआ", "Your device could not open the share menu.");
    }
  }

  function deleteData() {
    Alert.alert(
      "Delete all data? · सारा डेटा मिटाएँ?",
      "This permanently removes period dates, symptoms, mood entries and settings from this device. This cannot be undone.",
      [
        { text: "Cancel · रद्द करें", style: "cancel" },
        { text: "Delete · मिटाएँ", style: "destructive", onPress: async () => {
          await Notifications.cancelAllScheduledNotificationsAsync();
          await AsyncStorage.multiRemove([STORAGE_KEY, SETTINGS_KEY]);
          setEntries([]);
          setSettings(DEFAULT_SETTINGS);
          Alert.alert("Data deleted · डेटा मिटा दिया गया", "PeriodCare data was removed from this device.");
        }}
      ]
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.header}>
          <View>
            <Text style={styles.brand}>PeriodCare</Text>
            <Text style={styles.tagline}>Your cycle, your care · आपका चक्र, आपकी देखभाल</Text>
          </View>
          <Text style={styles.flower}>✿</Text>
        </View>

        <View style={styles.hero}>
          <Text style={styles.eyebrow}>YOUR CYCLE · आपका पीरियड</Text>
          <Text style={styles.heroTitle}>
            {daysToNext === undefined ? "Your cycle starts here" :
              daysToNext >= 0 ? `${daysToNext} days to your estimated next period` :
              `${Math.abs(daysToNext)} days past your estimate`}
          </Text>
          <Text style={styles.heroHindi}>
            {daysToNext === undefined ? "कैलेंडर में तारीख चुनकर शुरुआत करें" : "यह सिर्फ अनुमान है, पक्की तारीख नहीं।"}
          </Text>
          <Pressable style={styles.primaryButton} onPress={() => updateSelected({ period: !selected?.period })}>
            <Text style={styles.primaryText}>
              {selected?.period ? "✓ Period day saved · पीरियड दर्ज है" : "＋ Mark selected day as period · पीरियड दर्ज करें"}
            </Text>
          </Pressable>
          <Text style={styles.selectedHint}>Selected date · चुनी हुई तारीख: {pretty(selectedDate)}</Text>
        </View>

        <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>Cycle calendar · पीरियड कैलेंडर</Text></View>
        <View style={styles.calendar}>
          <View style={styles.monthBar}>
            <Pressable onPress={() => changeMonth(-1)} style={styles.monthArrow}><Text style={styles.arrowText}>‹</Text></Pressable>
            <Text style={styles.monthTitle}>{month.toLocaleDateString(undefined, { month: "long", year: "numeric" })}</Text>
            <Pressable onPress={() => changeMonth(1)} style={styles.monthArrow}><Text style={styles.arrowText}>›</Text></Pressable>
          </View>
          <View style={styles.weekRow}>{["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(day => <Text key={day} style={styles.weekDay}>{day}</Text>)}</View>
          <View style={styles.daysGrid}>
            {calendarCells.map((day, index) => {
              if (!day) return <View key={`blank-${index}`} style={styles.dayCell} />;
              const dateKey = keyOf(new Date(month.getFullYear(), month.getMonth(), day));
              const isPeriod = entries.some(e => e.date === dateKey && e.period);
              const isSelected = selectedDate === dateKey;
              return <Pressable key={dateKey} onPress={() => setSelectedDate(dateKey)} style={[styles.dayCell, isSelected && styles.daySelected, isPeriod && styles.dayPeriod]}>
                <Text style={[styles.dayText, isSelected && styles.daySelectedText, isPeriod && styles.dayPeriodText]}>{day}</Text>
              </Pressable>;
            })}
          </View>
          <Text style={styles.legend}>● Period logged · पीरियड दर्ज | Tap a date to add notes · तारीख चुनें</Text>
        </View>

        <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>How are you feeling? · कैसा महसूस हो रहा है?</Text></View>
        <View style={styles.card}>
          <Text style={styles.cardHeading}>Symptoms · लक्षण</Text>
          <Text style={styles.helper}>Choose any that apply · जो लागू हों उन्हें चुनें</Text>
          <View style={styles.chips}>{SYMPTOMS.map(item => {
            const active = (selected?.symptoms || []).includes(item);
            return <Pressable key={item} onPress={() => toggleSymptom(item)} style={[styles.chip, active && styles.chipActive]}>
              <Text style={[styles.chipText, active && styles.chipTextActive]}>{item}</Text>
            </Pressable>;
          })}</View>
          <View style={styles.divider} />
          <Text style={styles.cardHeading}>Mood · मनोदशा</Text>
          <View style={styles.chips}>{MOODS.map(item => {
            const active = selected?.mood === item;
            return <Pressable key={item} onPress={() => updateSelected({ mood: active ? "" : item })} style={[styles.chip, active && styles.chipActive]}>
              <Text style={[styles.chipText, active && styles.chipTextActive]}>{item}</Text>
            </Pressable>;
          })}</View>
        </View>

        <View style={styles.card}>
          <Text style={styles.cardHeading}>Cycle settings · साइकिल सेटिंग्स</Text>
          <Text style={styles.helper}>Average cycle length · औसत चक्र की अवधि</Text>
          <View style={styles.settingRow}>
            <Pressable style={styles.stepButton} onPress={() => saveSettings({ ...settings, cycleLength: Math.max(21, settings.cycleLength - 1) })}><Text style={styles.stepText}>−</Text></Pressable>
            <View style={styles.cycleNumber}><Text style={styles.cycleValue}>{settings.cycleLength}</Text><Text style={styles.cycleUnit}>days · दिन</Text></View>
            <Pressable style={styles.stepButton} onPress={() => saveSettings({ ...settings, cycleLength: Math.min(45, settings.cycleLength + 1) })}><Text style={styles.stepText}>＋</Text></Pressable>
          </View>
          <Text style={styles.helper}>Choose 21–45 days. This setting changes the estimate only; actual cycles can vary.</Text>
          <View style={styles.divider} />
          <View style={styles.reminderRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardHeading}>Period reminders · रिमाइंडर</Text>
              <Text style={styles.helper}>One reminder 2 days before the estimated date, at 9 AM.</Text>
            </View>
            <Pressable onPress={() => setReminder(!settings.reminders)} style={[styles.toggle, settings.reminders && styles.toggleOn]}>
              <Text style={styles.toggleText}>{settings.reminders ? "ON" : "OFF"}</Text>
            </Pressable>
          </View>
          {Platform.OS === "android" ? <Text style={styles.helper}>Your phone may have battery or notification settings that affect delivery.</Text> : null}
        </View>

        <View style={styles.card}>
          <Text style={styles.cardHeading}>Your overview · आपकी जानकारी</Text>
          <Text style={styles.overviewLabel}>Last period start · पिछली शुरुआत</Text>
          <Text style={styles.overviewValue}>{pretty(lastPeriod)}</Text>
          <Text style={styles.overviewLabel}>Next period estimate · अगला अनुमान</Text>
          <Text style={styles.overviewValue}>{pretty(nextEstimate)}</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.cardHeading}>Your data · आपका डेटा</Text>
          <Text style={styles.helper}>Export a copy or permanently delete information stored on this phone.</Text>
          <Pressable style={styles.secondaryButton} onPress={exportData}><Text style={styles.secondaryText}>Export my data · डेटा एक्सपोर्ट करें</Text></Pressable>
          <Pressable style={styles.deleteButton} onPress={deleteData}><Text style={styles.deleteText}>Delete all my data · सारा डेटा मिटाएँ</Text></Pressable>
        </View>

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>A gentle reminder · ज़रूरी जानकारी</Text>
          <Text style={styles.infoText}>Cycle length and symptoms vary. Predictions are estimates, not a diagnosis, contraception method, or fertility advice. For health concerns, speak with a trusted adult or healthcare professional.</Text>
          <Text style={styles.infoHindi}>आपका डेटा इस डिवाइस पर सेव होता है। एक्सपोर्ट करने पर आप इसे शेयर कर सकती हैं।</Text>
        </View>
        <View style={styles.footer}>
          <Text style={styles.footerText}>{loaded ? `${entries.length} date entries saved · तारीखें सेव` : "Loading · लोड हो रहा है…"}</Text>
          <Text style={styles.footerText}>PeriodCare · Version 3 prototype</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#FFF8FC" }, container: { padding: 18, paddingBottom: 38 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 10, marginBottom: 20 },
  brand: { fontSize: 28, fontWeight: "800", color: "#492B48" }, tagline: { color: "#80677F", fontSize: 11, marginTop: 4 }, flower: { fontSize: 34, color: "#D77EB2" },
  hero: { backgroundColor: "#F4DDEC", borderRadius: 24, padding: 18, marginBottom: 22 }, eyebrow: { color: "#87527A", fontSize: 11, fontWeight: "800", letterSpacing: 1 },
  heroTitle: { color: "#492B48", fontSize: 23, lineHeight: 30, fontWeight: "800", marginTop: 10 }, heroHindi: { color: "#76566F", fontSize: 13, marginTop: 7 },
  primaryButton: { backgroundColor: "#9C5B8C", padding: 13, borderRadius: 14, marginTop: 16 }, primaryText: { color: "white", fontWeight: "700", textAlign: "center", lineHeight: 20, fontSize: 13 }, selectedHint: { color: "#76566F", fontSize: 11, marginTop: 10 },
  sectionHeader: { marginBottom: 10, marginTop: 3 }, sectionTitle: { color: "#492B48", fontSize: 17, fontWeight: "800" },
  calendar: { backgroundColor: "white", borderRadius: 20, padding: 14, borderWidth: 1, borderColor: "#F0E3ED", marginBottom: 20 },
  monthBar: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }, monthArrow: { width: 36, height: 34, borderRadius: 12, backgroundColor: "#F9EDF5", alignItems: "center", justifyContent: "center" },
  arrowText: { color: "#87527A", fontSize: 24, lineHeight: 26 }, monthTitle: { color: "#492B48", fontSize: 16, fontWeight: "800" }, weekRow: { flexDirection: "row", justifyContent: "space-around", marginBottom: 6 },
  weekDay: { width: "14.28%", textAlign: "center", color: "#9A8295", fontSize: 10, fontWeight: "700" }, daysGrid: { flexDirection: "row", flexWrap: "wrap" },
  dayCell: { width: "14.28%", height: 40, alignItems: "center", justifyContent: "center", borderRadius: 12, marginVertical: 2 }, daySelected: { borderWidth: 1.5, borderColor: "#9C5B8C" },
  dayPeriod: { backgroundColor: "#F4DDEC" }, dayText: { color: "#594656", fontSize: 13 }, daySelectedText: { fontWeight: "800", color: "#6D3F64" }, dayPeriodText: { color: "#713D66", fontWeight: "800" },
  legend: { color: "#9A8295", fontSize: 10, marginTop: 10, textAlign: "center" }, card: { backgroundColor: "white", borderRadius: 18, padding: 16, borderWidth: 1, borderColor: "#F0E3ED", marginBottom: 14 },
  cardHeading: { color: "#492B48", fontSize: 16, fontWeight: "800" }, helper: { color: "#9A8295", fontSize: 11, marginTop: 5, lineHeight: 16 }, chips: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 12 },
  chip: { borderRadius: 18, borderWidth: 1, borderColor: "#EAD9E6", paddingVertical: 9, paddingHorizontal: 11, backgroundColor: "#FFFBFD" }, chipActive: { backgroundColor: "#F4DDEC", borderColor: "#B779A6" },
  chipText: { color: "#76566F", fontSize: 11, fontWeight: "600" }, chipTextActive: { color: "#623B5C", fontWeight: "800" }, divider: { height: 1, backgroundColor: "#F1E6EF", marginTop: 17, marginBottom: 15 },
  settingRow: { flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 26, marginVertical: 12 }, stepButton: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#F9EDF5", alignItems: "center", justifyContent: "center" },
  stepText: { fontSize: 25, color: "#87527A", fontWeight: "700" }, cycleNumber: { alignItems: "center", minWidth: 70 }, cycleValue: { color: "#492B48", fontSize: 27, fontWeight: "800" }, cycleUnit: { color: "#92778D", fontSize: 11 },
  reminderRow: { flexDirection: "row", alignItems: "center", gap: 10 }, toggle: { backgroundColor: "#EDE5EC", borderRadius: 20, paddingVertical: 9, paddingHorizontal: 16 }, toggleOn: { backgroundColor: "#9C5B8C" }, toggleText: { color: "#6B5368", fontWeight: "800", fontSize: 11 },
  overviewLabel: { color: "#9A8295", fontSize: 11, marginTop: 13 }, overviewValue: { color: "#492B48", fontSize: 16, fontWeight: "700", marginTop: 4 },
  secondaryButton: { backgroundColor: "#F4DDEC", borderRadius: 13, padding: 13, marginTop: 12 }, secondaryText: { color: "#623B5C", textAlign: "center", fontWeight: "800", fontSize: 13 },
  deleteButton: { borderWidth: 1, borderColor: "#E8B8C7", borderRadius: 13, padding: 13, marginTop: 9 }, deleteText: { color: "#A33D5A", textAlign: "center", fontWeight: "800", fontSize: 13 },
  infoCard: { backgroundColor: "#F9EDF5", borderRadius: 18, padding: 16, marginTop: 2 }, infoTitle: { color: "#492B48", fontSize: 15, fontWeight: "800", marginBottom: 7 },
  infoText: { color: "#6F5A6B", fontSize: 12, lineHeight: 19 }, infoHindi: { color: "#8B7185", fontSize: 12, lineHeight: 19, marginTop: 8 },
  footer: { marginTop: 20, alignItems: "center", gap: 5 }, footerText: { color: "#9B8797", fontSize: 10, textAlign: "center" }
});
